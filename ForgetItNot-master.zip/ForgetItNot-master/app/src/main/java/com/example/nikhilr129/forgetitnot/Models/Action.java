package com.example.nikhilr129.forgetitnot.Models;

import io.realm.RealmObject;

/**
 * Created by nikhilr129 on 22/4/17.
 */

public class Action extends RealmObject {
    public String type;
    public String a0;
    public String a1;
    public String a2;
    public String a3;
    public Action()
    {

    }

}
